import 'dart:convert';

/// Fréquence d'une automatisation.
enum Repeat { once, daily, weekly, monthly }

extension RepeatLabel on Repeat {
  String get label {
    switch (this) {
      case Repeat.once:
        return 'Une seule fois';
      case Repeat.daily:
        return 'Tous les jours';
      case Repeat.weekly:
        return 'Chaque semaine';
      case Repeat.monthly:
        return 'Chaque mois';
    }
  }
}

const List<String> kWeekdayShort = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

/// Une tâche automatisée : une notification qui se répète selon une règle.
class AutoTask {
  AutoTask({
    required this.id,
    required this.title,
    this.note = '',
    this.emoji = '🔔',
    this.hour = 9,
    this.minute = 0,
    this.repeat = Repeat.daily,
    Set<int>? weekdays,
    this.date,
    this.dayOfMonth = 1,
    this.enabled = true,
    this.lastDone,
    this.doneCount = 0,
  }) : weekdays = weekdays ?? <int>{};

  /// Identifiant unique (assez petit pour que id * 10 + 7 tienne dans un int32).
  final int id;
  String title;
  String note;
  String emoji;
  int hour;
  int minute;
  Repeat repeat;

  /// Jours de la semaine pour [Repeat.weekly] (1 = lundi … 7 = dimanche).
  Set<int> weekdays;

  /// Date pour [Repeat.once].
  DateTime? date;

  /// Jour du mois (1–28) pour [Repeat.monthly].
  int dayOfMonth;

  bool enabled;
  DateTime? lastDone;
  int doneCount;

  static int newId() => DateTime.now().millisecondsSinceEpoch % 100000000;

  String get timeLabel =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  /// Description lisible de la récurrence.
  String get scheduleLabel {
    switch (repeat) {
      case Repeat.once:
        final d = date;
        if (d == null) return 'Une seule fois';
        return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} à $timeLabel';
      case Repeat.daily:
        return 'Tous les jours à $timeLabel';
      case Repeat.weekly:
        final days = weekdays.toList()..sort();
        if (days.isEmpty) return 'Chaque semaine (aucun jour choisi)';
        return '${days.map((d) => kWeekdayShort[d - 1]).join(', ')} à $timeLabel';
      case Repeat.monthly:
        return 'Le $dayOfMonth de chaque mois à $timeLabel';
    }
  }

  /// Prochaine échéance strictement après [from] (maintenant par défaut),
  /// ou null s'il n'y en a plus.
  DateTime? nextOccurrence([DateTime? from]) {
    final now = from ?? DateTime.now();
    switch (repeat) {
      case Repeat.once:
        final d = date;
        if (d == null) return null;
        final t = DateTime(d.year, d.month, d.day, hour, minute);
        return t.isAfter(now) ? t : null;
      case Repeat.daily:
        for (var i = 0; i <= 1; i++) {
          final t = DateTime(now.year, now.month, now.day + i, hour, minute);
          if (t.isAfter(now)) return t;
        }
        return null;
      case Repeat.weekly:
        if (weekdays.isEmpty) return null;
        for (var i = 0; i <= 7; i++) {
          final t = DateTime(now.year, now.month, now.day + i, hour, minute);
          if (weekdays.contains(t.weekday) && t.isAfter(now)) return t;
        }
        return null;
      case Repeat.monthly:
        for (var i = 0; i < 24; i++) {
          final t = DateTime(now.year, now.month + i, dayOfMonth, hour, minute);
          if (t.day == dayOfMonth && t.isAfter(now)) return t;
        }
        return null;
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'note': note,
        'emoji': emoji,
        'hour': hour,
        'minute': minute,
        'repeat': repeat.name,
        'weekdays': weekdays.toList(),
        'date': date?.toIso8601String(),
        'dayOfMonth': dayOfMonth,
        'enabled': enabled,
        'lastDone': lastDone?.toIso8601String(),
        'doneCount': doneCount,
      };

  factory AutoTask.fromJson(Map<String, dynamic> j) => AutoTask(
        id: j['id'] as int,
        title: j['title'] as String? ?? '',
        note: j['note'] as String? ?? '',
        emoji: j['emoji'] as String? ?? '🔔',
        hour: j['hour'] as int? ?? 9,
        minute: j['minute'] as int? ?? 0,
        repeat: Repeat.values.firstWhere(
          (r) => r.name == j['repeat'],
          orElse: () => Repeat.daily,
        ),
        weekdays: ((j['weekdays'] as List?) ?? const []).cast<int>().toSet(),
        date: j['date'] == null ? null : DateTime.tryParse(j['date'] as String),
        dayOfMonth: j['dayOfMonth'] as int? ?? 1,
        enabled: j['enabled'] as bool? ?? true,
        lastDone:
            j['lastDone'] == null ? null : DateTime.tryParse(j['lastDone'] as String),
        doneCount: j['doneCount'] as int? ?? 0,
      );

  AutoTask copy() => AutoTask.fromJson(
        jsonDecode(jsonEncode(toJson())) as Map<String, dynamic>,
      );
}
