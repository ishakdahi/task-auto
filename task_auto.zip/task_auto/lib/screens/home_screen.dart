import 'package:flutter/material.dart';

import '../models/auto_task.dart';
import '../services/notification_service.dart';
import '../state/task_store.dart';
import 'edit_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.store});

  final TaskStore store;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  bool _notifAllowed = true;

  TaskStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _askPermissions();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refreshPermission();
  }

  Future<void> _askPermissions() async {
    await NotificationService.instance.requestPermissions();
    await _refreshPermission();
  }

  Future<void> _refreshPermission() async {
    final ok = await NotificationService.instance.notificationsAllowed();
    if (mounted && ok != _notifAllowed) setState(() => _notifAllowed = ok);
  }

  Future<void> _openEditor([AutoTask? task]) async {
    final result = await Navigator.of(context).push<AutoTask>(
      MaterialPageRoute(builder: (_) => EditScreen(task: task)),
    );
    if (result != null) await store.upsert(result);
  }

  Future<void> _confirmDelete(AutoTask task) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer la tâche ?'),
        content: Text('« ${task.title} » et ses notifications seront supprimées.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );
    if (ok == true) await store.remove(task);
  }

  String _formatWhen(DateTime when) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(when.year, when.month, when.day);
    final diff = day.difference(today).inDays;
    final hm =
        '${when.hour.toString().padLeft(2, '0')}:${when.minute.toString().padLeft(2, '0')}';
    if (diff == 0) return "aujourd'hui à $hm";
    if (diff == 1) return 'demain à $hm';
    return 'le ${when.day.toString().padLeft(2, '0')}/${when.month.toString().padLeft(2, '0')} à $hm';
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final tasks = store.tasks;
        return Scaffold(
          appBar: AppBar(
            title: const Text('Mes automatisations'),
            actions: [
              IconButton(
                tooltip: 'Envoyer une notification de test',
                icon: const Icon(Icons.notifications_active_outlined),
                onPressed: () async {
                  await NotificationService.instance.showTest();
                  await _refreshPermission();
                },
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openEditor(),
            icon: const Icon(Icons.add),
            label: const Text('Nouvelle tâche'),
          ),
          body: !store.loaded
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
                  children: [
                    if (!_notifAllowed) _permissionBanner(context),
                    _summaryCard(context),
                    const SizedBox(height: 8),
                    if (tasks.isEmpty)
                      _emptyState(context)
                    else
                      for (final t in tasks) _taskCard(context, t),
                  ],
                ),
        );
      },
    );
  }

  Widget _permissionBanner(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      color: scheme.errorContainer,
      child: ListTile(
        leading: Icon(Icons.notifications_off, color: scheme.onErrorContainer),
        title: Text(
          'Notifications désactivées',
          style: TextStyle(color: scheme.onErrorContainer),
        ),
        subtitle: Text(
          "Autorisez-les dans les paramètres Android pour recevoir vos rappels.",
          style: TextStyle(color: scheme.onErrorContainer),
        ),
        trailing: TextButton(
          onPressed: _askPermissions,
          child: const Text('Autoriser'),
        ),
      ),
    );
  }

  Widget _summaryCard(BuildContext context) {
    final next = store.next;
    final scheme = Theme.of(context).colorScheme;
    return Card(
      color: scheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(Icons.bolt, size: 36, color: scheme.onPrimaryContainer),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${store.activeCount} automatisation${store.activeCount > 1 ? 's' : ''} active${store.activeCount > 1 ? 's' : ''}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: scheme.onPrimaryContainer,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    next == null
                        ? 'Aucune échéance à venir'
                        : 'Prochaine : ${next.task.emoji} ${next.task.title}, ${_formatWhen(next.when)}',
                    style: TextStyle(color: scheme.onPrimaryContainer),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyState(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 48, horizontal: 24),
      child: Column(
        children: [
          Icon(Icons.auto_awesome,
              size: 64, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 16),
          Text(
            'Aucune tâche pour le moment',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          const Text(
            'Créez une tâche : elle vous notifiera automatiquement, une fois ou en boucle.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _taskCard(BuildContext context, AutoTask t) {
    final scheme = Theme.of(context).colorScheme;
    final next = t.enabled ? t.nextOccurrence() : null;
    final subtitle = StringBuffer(t.scheduleLabel);
    if (next != null) subtitle.write('\nProchaine : ${_formatWhen(next)}');
    if (t.doneCount > 0) subtitle.write('\nFaite ${t.doneCount} fois');

    return Dismissible(
      key: ValueKey('task-${t.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        margin: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: scheme.errorContainer,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(Icons.delete, color: scheme.onErrorContainer),
      ),
      confirmDismiss: (_) async {
        await _confirmDelete(t);
        return false; // la suppression met elle-même la liste à jour
      },
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 4),
        child: Opacity(
          opacity: t.enabled ? 1 : 0.55,
          child: ListTile(
            contentPadding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
            leading: Text(t.emoji, style: const TextStyle(fontSize: 28)),
            title: Text(
              t.title,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle: Text(subtitle.toString()),
            isThreeLine: true,
            onTap: () => _openEditor(t),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  tooltip: 'Marquer comme faite',
                  icon: const Icon(Icons.check_circle_outline),
                  onPressed: () async {
                    await store.markDone(t);
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('« ${t.title} » marquée comme faite')),
                    );
                  },
                ),
                Switch(
                  value: t.enabled,
                  onChanged: (v) => store.setEnabled(t, v),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
