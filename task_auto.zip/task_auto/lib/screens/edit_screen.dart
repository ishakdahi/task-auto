import 'package:flutter/material.dart';

import '../models/auto_task.dart';

const List<String> kEmojis = ['🔔', '💊', '💧', '📞', '🧹', '🛒', '📚', '🏃', '🍽️', '💼', '🚗', '🌙'];

/// Création / modification d'une tâche. Renvoie l'[AutoTask] validé via Navigator.pop.
class EditScreen extends StatefulWidget {
  const EditScreen({super.key, this.task});

  final AutoTask? task;

  @override
  State<EditScreen> createState() => _EditScreenState();
}

class _EditScreenState extends State<EditScreen> {
  final _formKey = GlobalKey<FormState>();
  late AutoTask _t;
  late final TextEditingController _title;
  late final TextEditingController _note;

  bool get _isNew => widget.task == null;

  @override
  void initState() {
    super.initState();
    _t = widget.task?.copy() ??
        AutoTask(
          id: AutoTask.newId(),
          title: '',
          date: DateTime.now(),
          dayOfMonth: DateTime.now().day.clamp(1, 28).toInt(),
          weekdays: {DateTime.now().weekday},
        );
    _t.date ??= DateTime.now();
    _title = TextEditingController(text: _t.title);
    _note = TextEditingController(text: _t.note);
  }

  @override
  void dispose() {
    _title.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: _t.hour, minute: _t.minute),
      builder: (ctx, child) => MediaQuery(
        data: MediaQuery.of(ctx).copyWith(alwaysUse24HourFormat: true),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        _t.hour = picked.hour;
        _t.minute = picked.minute;
      });
    }
  }

  Future<void> _pickDate() async {
    final today = DateTime.now();
    final initial = (_t.date ?? today).isBefore(DateTime(today.year, today.month, today.day))
        ? today
        : (_t.date ?? today);
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(today.year, today.month, today.day),
      lastDate: DateTime(today.year + 5),
    );
    if (picked != null) setState(() => _t.date = picked);
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    if (_t.repeat == Repeat.weekly && _t.weekdays.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Choisissez au moins un jour de la semaine.')),
      );
      return;
    }
    if (_t.repeat == Repeat.once) {
      final when = _t.nextOccurrence();
      if (when == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cette date et cette heure sont déjà passées.')),
        );
        return;
      }
    }

    _t
      ..title = _title.text.trim()
      ..note = _note.text.trim();
    Navigator.of(context).pop(_t);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dateLabel = _t.date == null
        ? '—'
        : '${_t.date!.day.toString().padLeft(2, '0')}/${_t.date!.month.toString().padLeft(2, '0')}/${_t.date!.year}';

    return Scaffold(
      appBar: AppBar(
        title: Text(_isNew ? 'Nouvelle tâche' : 'Modifier la tâche'),
        actions: [
          TextButton(onPressed: _save, child: const Text('Enregistrer')),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _title,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Titre',
                border: OutlineInputBorder(),
              ),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Donnez un titre à la tâche' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _note,
              minLines: 2,
              maxLines: 4,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Message de la notification (facultatif)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            Text('Icône', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final e in kEmojis)
                  ChoiceChip(
                    label: Text(e, style: const TextStyle(fontSize: 20)),
                    selected: _t.emoji == e,
                    onSelected: (_) => setState(() => _t.emoji = e),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            Text('Répétition', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            SegmentedButton<Repeat>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: Repeat.once, label: Text('1 fois')),
                ButtonSegment(value: Repeat.daily, label: Text('Jour')),
                ButtonSegment(value: Repeat.weekly, label: Text('Semaine')),
                ButtonSegment(value: Repeat.monthly, label: Text('Mois')),
              ],
              selected: {_t.repeat},
              onSelectionChanged: (s) => setState(() => _t.repeat = s.first),
            ),
            const SizedBox(height: 12),
            if (_t.repeat == Repeat.once)
              ListTile(
                shape: RoundedRectangleBorder(
                  side: BorderSide(color: scheme.outlineVariant),
                  borderRadius: BorderRadius.circular(12),
                ),
                leading: const Icon(Icons.event),
                title: const Text('Date'),
                trailing: Text(dateLabel),
                onTap: _pickDate,
              ),
            if (_t.repeat == Repeat.weekly)
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (var d = 1; d <= 7; d++)
                    FilterChip(
                      label: Text(kWeekdayShort[d - 1]),
                      selected: _t.weekdays.contains(d),
                      onSelected: (on) => setState(() {
                        if (on) {
                          _t.weekdays.add(d);
                        } else {
                          _t.weekdays.remove(d);
                        }
                      }),
                    ),
                ],
              ),
            if (_t.repeat == Repeat.monthly)
              DropdownButtonFormField<int>(
                initialValue: _t.dayOfMonth,
                decoration: const InputDecoration(
                  labelText: 'Jour du mois',
                  helperText: 'Limité au 28 pour exister tous les mois',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (var d = 1; d <= 28; d++)
                    DropdownMenuItem(value: d, child: Text('$d')),
                ],
                onChanged: (v) => setState(() => _t.dayOfMonth = v ?? 1),
              ),
            const SizedBox(height: 12),
            ListTile(
              shape: RoundedRectangleBorder(
                side: BorderSide(color: scheme.outlineVariant),
                borderRadius: BorderRadius.circular(12),
              ),
              leading: const Icon(Icons.schedule),
              title: const Text('Heure'),
              trailing: Text(
                _t.timeLabel,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              onTap: _pickTime,
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              title: const Text('Activée'),
              value: _t.enabled,
              onChanged: (v) => setState(() => _t.enabled = v),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.check),
              label: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
  }
}
