import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/auto_task.dart';
import '../services/notification_service.dart';

/// Liste des tâches, sauvegardée localement et synchronisée avec les notifications.
class TaskStore extends ChangeNotifier {
  static const _key = 'tasks_v1';

  final List<AutoTask> _tasks = [];
  bool loaded = false;

  List<AutoTask> get tasks => List.unmodifiable(_tasks);

  int get activeCount => _tasks.where((t) => t.enabled).length;

  /// La prochaine tâche à se déclencher, toutes tâches actives confondues.
  ({AutoTask task, DateTime when})? get next {
    ({AutoTask task, DateTime when})? best;
    for (final t in _tasks) {
      if (!t.enabled) continue;
      final w = t.nextOccurrence();
      if (w != null && (best == null || w.isBefore(best.when))) {
        best = (task: t, when: w);
      }
    }
    return best;
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    _tasks.clear();
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        _tasks.addAll(
          list.map((e) => AutoTask.fromJson(Map<String, dynamic>.from(e as Map))),
        );
      } catch (e) {
        debugPrint('Lecture des tâches impossible : $e');
      }
    }
    _sort();
    loaded = true;
    notifyListeners();
    // Garantit que les notifications correspondent aux données (ex. après mise à jour).
    await NotificationService.instance.rescheduleAll(_tasks);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(_tasks.map((t) => t.toJson()).toList()));
  }

  void _sort() {
    _tasks.sort((a, b) {
      if (a.enabled != b.enabled) return a.enabled ? -1 : 1;
      final na = a.nextOccurrence();
      final nb = b.nextOccurrence();
      if (na == null && nb == null) return a.title.compareTo(b.title);
      if (na == null) return 1;
      if (nb == null) return -1;
      return na.compareTo(nb);
    });
  }

  Future<void> upsert(AutoTask task) async {
    final i = _tasks.indexWhere((t) => t.id == task.id);
    if (i >= 0) {
      _tasks[i] = task;
    } else {
      _tasks.add(task);
    }
    _sort();
    notifyListeners();
    await _save();
    await NotificationService.instance.schedule(task);
  }

  Future<void> remove(AutoTask task) async {
    _tasks.removeWhere((t) => t.id == task.id);
    notifyListeners();
    await _save();
    await NotificationService.instance.cancel(task);
  }

  Future<void> setEnabled(AutoTask task, bool value) async {
    task.enabled = value;
    _sort();
    notifyListeners();
    await _save();
    await NotificationService.instance.schedule(task);
  }

  /// Marque la tâche comme faite. Une tâche « une seule fois » est ensuite désactivée.
  Future<void> markDone(AutoTask task) async {
    task.lastDone = DateTime.now();
    task.doneCount += 1;
    if (task.repeat == Repeat.once) task.enabled = false;
    _sort();
    notifyListeners();
    await _save();
    await NotificationService.instance.schedule(task);
  }
}
