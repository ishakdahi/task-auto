import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../models/auto_task.dart';

/// Planifie les notifications locales des tâches (fonctionne hors ligne,
/// survit au redémarrage grâce au récepteur de boot déclaré dans le manifeste).
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  static const _channelId = 'task_auto_reminders';
  static const _channelName = 'Rappels de tâches';
  static const _channelDesc = 'Notifications des tâches automatisées';
  static const _askedExactKey = 'asked_exact_alarm';

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  Future<void> init() async {
    if (_ready) return;

    tzdata.initializeTimeZones();
    try {
      final name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name));
    } catch (e) {
      debugPrint('Fuseau horaire introuvable, repli sur UTC : $e');
      tz.setLocalLocation(tz.getLocation('UTC'));
    }

    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );
    await _plugin.initialize(settings);

    await _android?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDesc,
        importance: Importance.high,
      ),
    );
    _ready = true;
  }

  /// Demande l'autorisation de notifier (Android 13+) et, une seule fois,
  /// l'autorisation d'alarmes exactes (Android 12+).
  Future<bool> requestPermissions() async {
    final android = _android;
    if (android == null) return true;

    final granted = await android.requestNotificationsPermission() ?? true;

    final canExact = await android.canScheduleExactNotifications() ?? true;
    if (!canExact) {
      final prefs = await SharedPreferences.getInstance();
      if (!(prefs.getBool(_askedExactKey) ?? false)) {
        await prefs.setBool(_askedExactKey, true);
        await android.requestExactAlarmsPermission();
      }
    }
    return granted;
  }

  Future<bool> notificationsAllowed() async =>
      await _android?.areNotificationsEnabled() ?? true;

  NotificationDetails get _details => const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDesc,
          importance: Importance.high,
          priority: Priority.high,
        ),
      );

  /// Identifiants de notification d'une tâche : id*10 + (0 | 1..7).
  Iterable<int> _idsFor(AutoTask t) sync* {
    for (var k = 0; k <= 7; k++) {
      yield t.id * 10 + k;
    }
  }

  Future<void> cancel(AutoTask t) async {
    for (final nid in _idsFor(t)) {
      await _plugin.cancel(nid);
    }
  }

  Future<void> cancelAll() => _plugin.cancelAll();

  /// (Re)planifie toutes les notifications d'une tâche.
  Future<void> schedule(AutoTask t) async {
    if (!_ready) await init();
    await cancel(t);
    if (!t.enabled) return;

    final exact = await _android?.canScheduleExactNotifications() ?? false;
    final mode = exact
        ? AndroidScheduleMode.exactAllowWhileIdle
        : AndroidScheduleMode.inexactAllowWhileIdle;

    final title = '${t.emoji} ${t.title}';
    final body = t.note.isEmpty ? "C'est l'heure !" : t.note;

    Future<void> one(int nid, tz.TZDateTime when, DateTimeComponents? match) {
      return _plugin.zonedSchedule(
        nid,
        title,
        body,
        when,
        _details,
        androidScheduleMode: mode,
        matchDateTimeComponents: match,
        payload: t.id.toString(),
      );
    }

    final now = tz.TZDateTime.now(tz.local);

    switch (t.repeat) {
      case Repeat.once:
        final d = t.date;
        if (d == null) return;
        final when =
            tz.TZDateTime(tz.local, d.year, d.month, d.day, t.hour, t.minute);
        if (when.isAfter(now)) await one(t.id * 10, when, null);
        break;

      case Repeat.daily:
        var when = tz.TZDateTime(
            tz.local, now.year, now.month, now.day, t.hour, t.minute);
        if (!when.isAfter(now)) {
          when = tz.TZDateTime(
              tz.local, now.year, now.month, now.day + 1, t.hour, t.minute);
        }
        await one(t.id * 10, when, DateTimeComponents.time);
        break;

      case Repeat.weekly:
        for (final wd in t.weekdays) {
          var when = tz.TZDateTime(
              tz.local, now.year, now.month, now.day, t.hour, t.minute);
          while (when.weekday != wd || !when.isAfter(now)) {
            when = tz.TZDateTime(
                tz.local, when.year, when.month, when.day + 1, t.hour, t.minute);
          }
          await one(t.id * 10 + wd, when, DateTimeComponents.dayOfWeekAndTime);
        }
        break;

      case Repeat.monthly:
        var when = tz.TZDateTime(
            tz.local, now.year, now.month, t.dayOfMonth, t.hour, t.minute);
        if (!when.isAfter(now)) {
          when = tz.TZDateTime(
              tz.local, now.year, now.month + 1, t.dayOfMonth, t.hour, t.minute);
        }
        await one(t.id * 10, when, DateTimeComponents.dayOfMonthAndTime);
        break;
    }
  }

  Future<void> rescheduleAll(Iterable<AutoTask> tasks) async {
    for (final t in tasks) {
      await schedule(t);
    }
  }

  /// Notification immédiate pour vérifier que tout fonctionne.
  Future<void> showTest() async {
    if (!_ready) await init();
    await _plugin.show(
      0,
      '✅ Notification de test',
      'Les notifications fonctionnent correctement.',
      _details,
    );
  }
}
