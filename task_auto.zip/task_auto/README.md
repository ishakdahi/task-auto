# Task Auto — automatisation de tâches avec notifications (Flutter)

Application Android hors ligne : vous créez des tâches, elles vous notifient
automatiquement à l'heure choisie, une fois ou en boucle.

## Fonctionnalités

- Tâches avec titre, message, icône et heure
- Répétition : une seule fois, tous les jours, certains jours de la semaine, chaque mois
- Notifications locales planifiées (même application fermée, rétablies après redémarrage du téléphone)
- Activer / désactiver une tâche, la marquer comme faite, la supprimer (glisser vers la gauche)
- Résumé en haut : nombre de tâches actives et prochaine échéance
- Bouton « notification de test » dans la barre du haut
- Interface en français, thème clair/sombre automatique
- Données sauvegardées localement (aucun compte, aucun serveur)

## Compiler l'APK

### Option A — sur votre ordinateur

Prérequis : [Flutter](https://docs.flutter.dev/get-started/install) avec le SDK Android, et Python 3.

```bash
python tool/setup_android.py      # génère android/, ajoute permissions et désugarisation
flutter build apk --release
```

L'APK se trouve dans `build/app/outputs/flutter-apk/app-release.apk`.
Pour tester directement sur un téléphone branché : `flutter run`.

### Option B — sans rien installer (GitHub Actions)

1. Créez un dépôt GitHub et envoyez-y tout ce dossier.
2. Onglet **Actions** → workflow **Build APK** → **Run workflow** (il se lance aussi à chaque push).
3. Une fois terminé, téléchargez l'artefact **task-auto-apk** : il contient `app-release.apk`.

## Installer sur le téléphone

Copiez l'APK sur le téléphone et ouvrez-le (autorisez l'installation depuis cette source si Android le demande).

Au premier lancement, acceptez :
- **Notifications** (Android 13+)
- **Alarmes et rappels** (Android 12+) : pour une heure exacte. Sans cette autorisation, l'heure peut varier de quelques minutes.

Si les notifications n'arrivent pas sur certaines marques (Xiaomi, Huawei, Oppo…), désactivez l'optimisation
de batterie pour l'application et autorisez le démarrage automatique dans les paramètres du téléphone.

## Structure

```
lib/
  main.dart                          point d'entrée, thème, langue
  models/auto_task.dart              modèle, récurrence, calcul de la prochaine échéance
  services/notification_service.dart planification des notifications
  state/task_store.dart              liste des tâches + sauvegarde locale
  screens/home_screen.dart           liste et résumé
  screens/edit_screen.dart           création / modification
tool/setup_android.py                prépare le projet Android
.github/workflows/build-apk.yml      compilation automatique de l'APK
```

## Notes techniques

- `flutter_local_notifications` est volontairement limité à la série 19.x (`^19.0.0`) et
  `flutter_timezone` à la série 4.x : les séries suivantes changent la signature de plusieurs méthodes.
- L'APK « release » produit est signé avec la clé de debug, ce qui suffit pour l'installer sur votre
  téléphone. Pour publier sur le Play Store, il faudra une clé de signature propre.
