#!/usr/bin/env python3
"""Prépare le projet Android de Task Auto (multiplateforme : Windows, macOS, Linux).

1. Génère le dossier android/ avec `flutter create` s'il n'existe pas
   (sans écraser lib/, pubspec.yaml ni README.md).
2. Ajoute au manifeste les permissions et récepteurs nécessaires aux
   notifications planifiées (y compris le redémarrage du téléphone).
3. Active le « core library desugaring » exigé par flutter_local_notifications.
4. Lance `flutter pub get`.

Le script est idempotent : on peut le relancer sans risque.
Usage : python tool/setup_android.py
"""
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP_LABEL = "Task Auto"
DESUGAR_LIB = "com.android.tools:desugar_jdk_libs:2.1.4"

PERMISSIONS = [
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.VIBRATE",
    "android.permission.SCHEDULE_EXACT_ALARM",
]

RECEIVERS = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""


def fail(msg: str) -> None:
    print(f"ERREUR : {msg}", file=sys.stderr)
    sys.exit(1)


def flutter_cmd() -> str:
    path = shutil.which("flutter")
    if not path:
        fail("la commande `flutter` est introuvable. Installez Flutter : https://docs.flutter.dev/get-started/install")
    return path


def run(cmd: list[str]) -> None:
    print("$", " ".join(cmd))
    subprocess.run(cmd, cwd=ROOT, check=True)


def ensure_android_project() -> None:
    if (ROOT / "android").exists():
        print("android/ existe déjà : génération ignorée.")
        return
    flutter = flutter_cmd()
    with tempfile.TemporaryDirectory() as tmp:
        keep = Path(tmp)
        for name in ("pubspec.yaml", "README.md"):
            if (ROOT / name).exists():
                shutil.copy2(ROOT / name, keep / name)
        shutil.copytree(ROOT / "lib", keep / "lib")

        run([flutter, "create", "--project-name", "task_auto",
             "--org", "com.taskauto", "--platforms", "android", "."])

        # flutter create peut régénérer ces fichiers : on remet les nôtres.
        for name in ("pubspec.yaml", "README.md"):
            if (keep / name).exists():
                shutil.copy2(keep / name, ROOT / name)
        shutil.rmtree(ROOT / "lib")
        shutil.copytree(keep / "lib", ROOT / "lib")

    # Le test généré référence l'application « compteur » du modèle par défaut.
    (ROOT / "test" / "widget_test.dart").unlink(missing_ok=True)


def patch_manifest() -> None:
    path = ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
    if not path.exists():
        fail(f"manifeste introuvable : {path}")
    text = path.read_text(encoding="utf-8")

    missing = [p for p in PERMISSIONS if p not in text]
    if missing:
        block = "".join(f'    <uses-permission android:name="{p}"/>\n' for p in missing)
        idx = text.index("<application")
        text = text[:idx] + block.lstrip() + "    " + text[idx:]

    if "ScheduledNotificationReceiver" not in text:
        idx = text.rindex("</application>")
        text = text[:idx] + RECEIVERS.lstrip("\n") + "    " + text[idx:]

    text = re.sub(r'android:label="[^"]*"', f'android:label="{APP_LABEL}"', text, count=1)
    path.write_text(text, encoding="utf-8")
    print("AndroidManifest.xml : OK")


def patch_gradle() -> None:
    app_dir = ROOT / "android" / "app"
    kts = app_dir / "build.gradle.kts"
    groovy = app_dir / "build.gradle"

    if kts.exists():
        text = kts.read_text(encoding="utf-8")
        if "isCoreLibraryDesugaringEnabled" not in text:
            text, n = re.subn(r"(compileOptions\s*\{)", r"\1\n        isCoreLibraryDesugaringEnabled = true", text, count=1)
            if n == 0:
                fail("bloc compileOptions introuvable dans build.gradle.kts")
        if "coreLibraryDesugaring(" not in text:
            dep = f'    coreLibraryDesugaring("{DESUGAR_LIB}")'
            if re.search(r"^dependencies\s*\{", text, re.M):
                text = re.sub(r"(^dependencies\s*\{)", r"\1\n" + dep, text, count=1, flags=re.M)
            else:
                text += f"\ndependencies {{\n{dep}\n}}\n"
        kts.write_text(text, encoding="utf-8")
    elif groovy.exists():
        text = groovy.read_text(encoding="utf-8")
        if "coreLibraryDesugaringEnabled" not in text:
            text, n = re.subn(r"(compileOptions\s*\{)", r"\1\n        coreLibraryDesugaringEnabled true", text, count=1)
            if n == 0:
                fail("bloc compileOptions introuvable dans build.gradle")
        if "coreLibraryDesugaring '" not in text and 'coreLibraryDesugaring "' not in text:
            dep = f"    coreLibraryDesugaring '{DESUGAR_LIB}'"
            if re.search(r"^dependencies\s*\{", text, re.M):
                text = re.sub(r"(^dependencies\s*\{)", r"\1\n" + dep, text, count=1, flags=re.M)
            else:
                text += f"\ndependencies {{\n{dep}\n}}\n"
        groovy.write_text(text, encoding="utf-8")
    else:
        fail("build.gradle(.kts) introuvable dans android/app")
    print("build.gradle : OK (desugaring activé)")


def main() -> None:
    ensure_android_project()
    patch_manifest()
    patch_gradle()
    run([flutter_cmd(), "pub", "get"])
    print("\nTerminé. Compilez l'APK avec :  flutter build apk --release")


if __name__ == "__main__":
    main()
